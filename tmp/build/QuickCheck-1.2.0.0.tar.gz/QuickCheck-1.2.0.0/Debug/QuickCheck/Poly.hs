-----------------------------------------------------------------------------
-- |
-- Module      :  Debug.QuickCheck.Poly
-- Copyright   :  (c) Andy Gill 2001
-- License     :  BSD-style (see the file libraries/base/LICENSE)
-- 
-- Maintainer  :  libraries@haskell.org
-- Stability   :  deprecated
-- Portability :  portable
--
-----------------------------------------------------------------------------

module Debug.QuickCheck.Poly
{-# DEPRECATED "Use module Test.QuickCheck.Poly instead" #-}
  ( module Test.QuickCheck.Poly
  ) where

import Test.QuickCheck.Poly

